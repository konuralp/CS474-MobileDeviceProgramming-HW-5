package com.example.recyclerapp

import java.io.Serializable

data class Food(val name: String, val recipe: String, val image: Int): Serializable